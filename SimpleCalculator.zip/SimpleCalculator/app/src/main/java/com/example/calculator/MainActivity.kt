package com.example.calculator

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etNumber1 = findViewById<EditText>(R.id.etNumber1)
        val etNumber2 = findViewById<EditText>(R.id.etNumber2)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnSub = findViewById<Button>(R.id.btnSub)
        val btnMul = findViewById<Button>(R.id.btnMul)
        val btnDiv = findViewById<Button>(R.id.btnDiv)

        btnAdd.setOnClickListener { calculate(etNumber1, etNumber2, tvResult, "+") }
        btnSub.setOnClickListener { calculate(etNumber1, etNumber2, tvResult, "-") }
        btnMul.setOnClickListener { calculate(etNumber1, etNumber2, tvResult, "*") }
        btnDiv.setOnClickListener { calculate(etNumber1, etNumber2, tvResult, "/") }
    }

    private fun calculate(n1: EditText, n2: EditText, resultTv: TextView, op: String) {
        val str1 = n1.text.toString()
        val str2 = n2.text.toString()
        if (str1.isEmpty() || str2.isEmpty()) {
            resultTv.text = "الرجاء إدخال الرقمين"
            return
        }

        val num1 = str1.toDouble()
        val num2 = str2.toDouble()
        val res = when (op) {
            "+" -> num1 + num2
            "-" -> num1 - num2
            "*" -> num1 * num2
            "/" -> if (num2 != 0.0) num1 / num2 else {
                resultTv.text = "لا يمكن القسمة على الصفر"
                return
            }
            else -> 0.0
        }
        resultTv.text = "النتيجة: $res"
    }
}
